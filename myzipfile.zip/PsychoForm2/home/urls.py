from django.urls import path
from . import views


urlpatterns = [
    path('home/<int:uniq>/', views.home),
    path('proceed1/<int:uniq>/', views.proceed1),
    path('proceed2/<int:uniq>/', views.proceed2),
    path('proceed3/<int:uniq>/', views.proceed3),
    path('proceed4/<int:uniq>/', views.proceed4),
    path('proceed5/<int:uniq>/', views.proceed5),
    path('proceed6/<int:uniq>/', views.proceed6),
    path('proceed7/<int:uniq>/', views.proceed7),
    path('proceed8/<int:uniq>/', views.proceed8),
    path('proceedf/<int:uniq>/', views.proceedf),
    path('fform/<int:uniq>/', views.fform),
    path('thank/<int:uniq>/', views.thank),
    path('quest1/<int:uniq>/', views.question1),
    path('quest2/<int:uniq>/', views.question2),
    path('quest3/<int:uniq>/', views.question3),
    path('quest4/<int:uniq>/', views.question4),
    path('quest5/<int:uniq>/', views.question5),
    path('quest6/<int:uniq>/', views.question6),
    path('quest7/<int:uniq>/', views.question7),
    path('quest8/<int:uniq>/', views.question8),
    path('feedback/<int:uniq>/',views.feedbck),
    path('proceedh/<int:uniq>/',views.feedbck),
    path('',views.desc)
]