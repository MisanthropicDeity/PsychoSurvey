from django.contrib import admin
from home.models import submission,feedback

admin.site.register(submission)
admin.site.register(feedback)
# Register your models here.
